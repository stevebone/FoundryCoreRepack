-- Fix invalid faction which is NOT allowed
UPDATE `creature_template` SET `faction` = 35 WHERE `faction` = 0;

-- Loots that are 0.00000001 and the likes
UPDATE `creature_loot_template` SET `Chance` = 1 WHERE `Chance` < 1;

-- Fix missing MovementType 1 for creatures with wander_distance > 0 and reverse
UPDATE `creature` SET `MovementType` = 1 WHERE `wander_distance` > 0 AND `MovementType` != 2;
UPDATE `creature` SET `MovementType` = 0 WHERE `wander_distance` = 0 AND `MovementType` != 2;
UPDATE `creature` SET `wander_distance` = 0 WHERE `MovementType` = 0 AND `wander_distance` > 0;

-- Add missing swim static flags to creature template difficulty where those exist on spawn level
UPDATE `creature_template_difficulty` SET `StaticFlags1` = `StaticFlags1` | 0x10000000 WHERE `Entry` IN 
(
	23666, 23667, 23670, 26271, 26425, 26447, 26626, 26870, 26965, 27356, 28277, 28610, 28939, 28940, 
	28941, 28942, 29402, 29404, 30250, 31094, 31098, 32969, 33071, 37507, 38300, 39990, 40017, 40019, 
	41335, 58605, 60033, 73013, 73101, 73805, 77522, 82031, 95834, 95842, 96574, 97087, 158281, 220431, 
	252983, 91003, 98246, 129517, 150941, 150947,17023, 17377, 17416, 17534, 17603, 18607, 18613, 21215,
	21806, 21812, 21865, 21873, 21875, 21958, 22009, 22055, 22056, 32893, 32897, 32900, 32901, 32941, 32946,
	32948, 32950, 33325, 33326, 33327, 33328, 33330, 33331, 33332, 33333, 122967, 15471, 15473, 16580, 17993, 
	19507, 23232, 23235, 23236, 23237, 23287, 23542, 23580, 23581, 23582, 25242, 25243, 25244, 25275, 26159, 
	26734, 26736, 26737, 26761

);

-- Remove creature swim unit flag
UPDATE `creature` SET `unit_flags` = `unit_flags` & ~0x8000 WHERE `id` IN (
	23666, 23667, 23670, 26271, 26425, 26447, 26626, 26870, 26965, 27356, 28277, 28610, 28939, 28940, 
	28941, 28942, 29402, 29404, 30250, 31094, 31098, 32969, 33071, 37507, 38300, 39990, 40017, 40019, 
	41335, 58605, 60033, 73013, 73101, 73805, 77522, 82031, 95834, 95842, 96574, 97087, 158281, 220431, 
	252983, 91003, 98246, 129517, 150941, 150947,17023, 17377, 17416, 17534, 17603, 18607, 18613, 21215,
	21806, 21812, 21865, 21873, 21875, 21958, 22009, 22055, 22056, 32893, 32897, 32900, 32901, 32941, 32946,
	32948, 32950, 33325, 33326, 33327, 33328, 33330, 33331, 33332, 33333, 122967, 15471, 15473, 16580, 17993, 
	19507, 23232, 23235, 23236, 23237, 23287, 23542, 23580, 23581, 23582, 25242, 25243, 25244, 25275, 26159, 
	26734, 26736, 26737, 26761
);

-- Set unit flags as NULL if value is 0
UPDATE `creature` SET `unit_flags` = NULL WHERE `unit_flags` = 0;

-- Remove creature template swim unit flag
UPDATE `creature_template` SET `unit_flags` = `unit_flags` & ~0x8000 WHERE `entry` IN (
	23666, 23667, 23670, 26271, 26425, 26447, 26626, 26870, 26965, 27356, 28277, 28610, 28939, 28940, 
	28941, 28942, 29402, 29404, 30250, 31094, 31098, 32969, 33071, 37507, 38300, 39990, 40017, 40019, 
	41335, 58605, 60033, 73013, 73101, 73805, 77522, 82031, 95834, 95842, 96574, 97087, 158281, 220431, 
	252983, 91003, 98246, 129517, 150941, 150947,17023, 17377, 17416, 17534, 17603, 18607, 18613, 21215,
	21806, 21812, 21865, 21873, 21875, 21958, 22009, 22055, 22056, 32893, 32897, 32900, 32901, 32941, 32946,
	32948, 32950, 33325, 33326, 33327, 33328, 33330, 33331, 33332, 33333, 122967
);

-- Fix curHealth for spawns
UPDATE `creature` SET `curHealthPct` = NULL WHERE `curHealthPct` IS NOT NULL AND `id` IN (
    SELECT `entry` FROM `creature_template` WHERE `RegenHealth` = 1
);

-- Remove Invalid SAI
DELETE FROM `smart_scripts` WHERE `entryorguid` = 0;

UPDATE `creature_template` ct
SET ct.`npcflag` = ct.`npcflag` | 0x2
WHERE (ct.`npcflag` & 0x2) = 0
  AND ct.`entry` IN (
      SELECT `id` FROM `creature_queststarter`
      UNION
      SELECT `id` FROM `creature_questender`
  );
