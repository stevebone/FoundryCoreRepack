-- The Wandering Isle Creature Texts

-- Jojos
DELETE FROM `creature_text` WHERE `creatureID` IN (57669,57638,57670);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('57669', '0', '0', 'Our crafters build the finest wooden planks.  They would weather the most brutal of storms.  But they are as water before the storm of my crushing skull.', '12', '0', '100', '1', '0', '0', '56343', '0', 'Jojo Ironbrow to Player'),
('57669', '1', '0', 'Nothing made by pandaren hands can withstand me.', '12', '0', '100', '2', '0', '0', '56344', '0', 'Jojo Ironbrow to Player'),
('57638', '0', '0', 'The reeds of the Singing Pools are the hardest in all of the land, but they are as air before my mighty brow.', '12', '0', '100', '1', '0', '0', '56333', '0', 'Jojo Ironbrow to Player'),
('57638', '1', '0', 'Many have tested my claim, and I yet stand proven.', '12', '0', '100', '2', '0', '0', '56334', '0', 'Jojo Ironbrow to Player'),
('57670', '0', '0', 'These are the densest stones across all of Shen-zin Su, yet they are as nothing before my mighty head.', '12', '0', '100', '1', '0', '0', '56355', '0', 'Jojo Ironbrow to Player'),
('57670', '1', '0', 'Any who yet doubt my strength are simply foolish.', '12', '0', '100', '2', '0', '0', '56356', '0', 'Jojo Ironbrow to Player');

-- Huo Spirit of fire quest
DELETE FROM `creature_text` WHERE (`CreatureID` IN (54786, 60248, 60253, 61126, 61127));
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
(54786, 0, 0, 'Welcome, Huo. The people have missed your warmth.', 12, 0, 100, 2, 0, 27788, 0, 60608, 0, 'Master Shang Xi to Player'),
(60248, 0, 0, 'Is that... is that Huo?', 12, 0, 100, 25, 0, 0, 0, 59751, 0, 'Chia-hui Autumnleaf to Player'),
(60253, 0, 0, 'It is! Well done, $p!', 12, 0, 100, 71, 0, 0, 0, 59752, 0, 'Brewer Lin to Player'),
(54786, 1, 0, 'You have conquered every challenge I put before you, $n. You have found Huo and brought him safely to the temple.', 12, 0, 100, 1, 0, 27789, 0, 60600, 0, 'Master Shang Xi to Player'),
(54786, 1, 1, 'Your training has paid off, young $c. You have found Huo and brought him safely to the temple.', 12, 0, 100, 1, 0, 0, 0, 55254, 0, 'Master Shang Xi to Player'),
(54786, 2, 0, 'There is a much larger problem we face now, my students. Shen-zin Su is in pain. If we do not act, the very land on which we stand could die, and all of us with it.', 12, 0, 100, 1, 0, 27790, 0, 60601, 0, 'Master Shang Xi to Player'),
(54786, 3, 0, 'We need to speak to Shen-zin Su and discover how to heal it. And to do that, we need the four elemental spirits returned. Huo was the first.', 12, 0, 100, 1, 0, 27791, 0, 60602, 0, 'Master Shang Xi to Player'),
(54786, 4, 0, 'Ji, I''d like you to go to the Dai-Lo Farmstead in search of Wugou, the spirit of earth.', 12, 0, 100, 1, 0, 27792, 0, 60603, 0, 'Master Shang Xi to Player'),
(54786, 5, 0, 'Aysa, I want you to go to the Singing Pools to find Shu, the spirit of water.', 12, 0, 100, 1, 0, 27793, 0, 60604, 0, 'Master Shang Xi to Player'),
(54786, 6, 0, 'And $n, you shall be the hand that guides us all. Speak with me for a moment before you join Aysa at the Singing Pools to the east.', 12, 0, 100, 1, 0, 27794, 0, 60605, 0, 'Master Shang Xi to Player'),
(54786, 7, 0, 'Wugou and Shu are welcome here. We will care for them well.', 12, 0, 100, 1, 0, 27777, 0, 55296, 0, 'Master Shang Xi to Player'),
(54786, 8, 0, 'The only remaining spirit is Dafeng, who hides somewhere across the Dawning Span to the west.', 12, 0, 100, 1, 0, 27778, 0, 55297, 0, 'Master Shang Xi to Player'),
(54786, 9, 0, 'I can carry you to the top of the temple. Ji awaits you there to lead the way.', 12, 0, 100, 1, 0, 27779, 0, 55298, 0, 'Master Shang Xi to Player'),
(61126, 0, 0, 'Yes master.', 12, 0, 100, 2, 0, 27406, 0, 0, 0, 'Aysa Cloudsinger to Player'),
(61127, 0, 0, 'On it!', 12, 0, 100, 0, 0, 27306, 0, 60606, 0, 'Ji Firepaw to Player');

-- summoned children at temple
DELETE FROM `creature_text` WHERE (`CreatureID` IN (60250, 60249));
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`, `BroadcastTextId`, `comment`) VALUES
(60250, 0, 0, 'Hey there! Are you the one that brought back the fire spirit?', 12, 0, 100, 3, 0, 0, 0, 59875, 'Cai to Deng'),
(60250, 1, 0, 'Of course he was hot! Don''t be dumb, Deng.', 12, 0, 100, 5, 0, 0, 0, 59877, 'Cai to Deng'),
(60250, 2, 0, 'Nuh uh. Bet they could for sure kick you over that hill, though! Hah!', 12, 0, 100, 274, 0, 0, 0, 59880, 'Cai to Deng'),
(60250, 3, 0, 'Okay bye.', 12, 0, 100, 3, 0, 0, 0, 59878, 'Cai to Deng'),
(60249, 0, 0, 'Was he hot?  I bet he was hot!', 12, 0, 100, 6, 0, 0, 0, 59876, 'Deng to Cai'),
(60249, 1, 0, 'I bet you''re really strong, huh?  You could probably kick that bridge right in half if you wanted to!', 12, 0, 100, 6, 0, 0, 0, 59879, 'Deng to Cai'),
(60249, 2, 0, 'Bye!', 12, 0, 100, 3, 0, 0, 0, 59884, 'Deng to Cai');

-- Ji at Temple spire
DELETE FROM `creature_text` WHERE `CreatureID` = 55694;
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES 
('55694', '0', '0', 'Hey $p! This way to Morning Breeze Village.', '12', '0', '100', '0', '0', '27294', '54196', '0', 'Ji Firepaw to Player');

-- Ji at Farmstead and various mobs
DELETE FROM `creature_text` WHERE `creatureID` IN (55477,55483,55504);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('55477', '0', '0', 'Wake... up... DANGIT!', '12', '0', '100', '15', '0', '27345', '60447', '0', 'Ji Firepaw'),
('55477', '1', '0', 'This is ridiculous...', '12', '0', '100', '274', '0', '27346', '60448', '0', 'Ji Firepaw'),
('55477', '2', '0', 'You sleep like a rock!', '12', '0', '100', '5', '0', '27347', '60449', '0', 'Ji Firepaw'),
('55477', '3', '0', 'There\'s no way you\'ll sleep through THIS.', '12', '0', '100', '274', '0', '27348', '60450', '0', 'Ji Firepaw'),
('55477', '4', '0', 'Seriously?', '12', '0', '100', '18', '0', '27349', '60451', '0', 'Ji Firepaw'),
('55477', '5', '0', 'Why...', '12', '0', '100', '507', '0', '27350', '60452', '0', 'Ji Firepaw'),
('55477', '6', '0', 'won\'t...', '12', '0', '100', '509', '0', '27351', '60453', '0', 'Ji Firepaw'),
('55477', '7', '0', 'you...', '12', '0', '100', '507', '0', '27352', '60454', '0', 'Ji Firepaw'),
('55477', '8', '0', 'just...', '12', '0', '100', '509', '0', '27353', '60455', '0', 'Ji Firepaw'),
('55477', '9', '0', 'WAKE UP?!', '12', '0', '100', '22', '0', '27354', '60456', '0', 'Ji Firepaw'),
('55477', '10', '0', 'I will break you, little rock man!', '12', '0', '100', '25', '0', '27355', '60457', '0', 'Ji Firepaw'),
('55477', '11', '0', '%s sighs.', '16', '0', '100', '0', '0', '0', '55942', '0', 'Ji Firepaw to Player'),
('55483', '0', '0', 'Gimme all your vegetables!', '12', '0', '100', '0', '0', '0', '54873', '0', 'Plump Virmen to Player'),
('55483', '0', '1', 'AIIIIEEEEEEE!', '12', '0', '100', '0', '0', '0', '54874', '0', 'Plump Virmen to Player'),
('55483', '0', '2', 'This virmen land!', '12', '0', '100', '0', '0', '0', '54876', '0', 'Plump Virmen to Player'),
('55483', '0', '3', 'You no take carrot! You take turnip instead!', '12', '0', '100', '0', '0', '0', '54877', '0', 'Plump Virmen to Player'),
('55483', '0', '4', 'We rowdy!', '12', '0', '100', '0', '0', '0', '54875', '0', 'Plump Virmen to Player'),
('55504', '0', '0', 'Gimme all your vegetables!', '12', '0', '100', '0', '0', '0', '54873', '0', 'Plump Carrotcruncher to Player'),
('55504', '0', '1', 'AIIIIEEEEEEE!', '12', '0', '100', '0', '0', '0', '54874', '0', 'Plump Carrotcruncher to Player'),
('55504', '0', '2', 'This virmen land!', '12', '0', '100', '0', '0', '0', '54876', '0', 'Plump Carrotcruncher to Player'),
('55504', '0', '3', 'You no take carrot! You take turnip instead!', '12', '0', '100', '0', '0', '0', '54877', '0', 'Plump Carrotcruncher to Player'),
('55504', '0', '4', 'We rowdy!', '12', '0', '100', '0', '0', '0', '54875', '0', 'Plump Carrotcruncher to Player');

-- Wugou sleeping
DELETE FROM `creature_text` WHERE `creatureID` IN (55539);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('55539', '0', '0', '%s snorts loudly, and continues sleeping.', '16', '0', '100', '0', '0', '0', '54991', '0', 'Wugou to Player');

-- Cart Tender
DELETE FROM `creature_text` WHERE `CreatureID` = 57712;
INSERT INTO `creature_text` (`CreatureID`,`GroupID`,`ID`,`Text`,`Type`,`Language`,`Probability`,`Emote`,`Duration`,`Sound`,`BroadcastTextId`,`TextRange`,`comment`) VALUES 
(57712,0,0,'Hello friend!  You\'re welcome to use my cart if you like.  It will take you to the Dai-Lo Farmstead.',12,0,100,3,0,0,56406,0,'Delivery Cart Tender to Player'),
(57712,1,0,'Hello friend!  You\'re welcome to use my cart if you like.  It will take you to the Temple of Five Dawns.',12,0,100,3,0,0,56415,0,'Delivery Cart Tender to Player');

-- Aysa at A new friend quest
DELETE FROM `creature_text` WHERE `CreatureID` = 54975;
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`, `BroadcastTextId`, `TextRange`, `comment`) VALUES 
('54975', '0', '0', 'I have to admit, that looked pretty fun!', '12', '0', '100', '0', '0', '27394', '0', '66056', '1', 'Aysa Cloudsinger - quest A new friend'),
('54975', '1', '0', 'And it looks to me like you made a new friend.', '12', '0', '100', '0', '0', '27395', '0', '66057', '1', 'Aysa Cloudsinger - quest A new friend');

DELETE FROM `creature_text` WHERE `CreatureID` IN (64885,64881,64880,64879,64875);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES 
('64885', '0', '0', 'Hello $n! The Lorewalker is beginning her lesson just down these stairs if you want to listen in.', '12', '0', '100', '3', '0', '0', '65573', '0', 'Lorewalker Zan to player'),
('64875', '0', '0', 'This is the Song of Liu Lang, the first pandaren explorer.', '12', '0', '100', '1', '0', '0', '65583', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '1', '0', 'The song is written in the old tongue, the language of emperors and scholars. Hardly anyone speaks it anymore.', '12', '0', '100', '6', '0', '0', '65584', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '2', '0', 'It is all about his adventures.', '12', '0', '100', '273', '0', '0', '65585', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '3', '0', 'Brave Liu Lang set out to explore the world on the back of a sea turtle.', '12', '0', '100', '1', '0', '0', '65586', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '4', '0', 'Does anyone remember the turtle\'s name? Yin?', '12', '0', '100', '25', '0', '0', '65587', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '5', '0', 'That\'s right, the turtle was called Shen-zin Su. At first, he was only big enough for Liu Lang to sit on.', '12', '0', '100', '1', '0', '0', '65588', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '6', '0', 'He grew and grew and grew, SO big, that now some people call him \"The Wandering Isle.\"', '12', '0', '100', '1', '0', '0', '65589', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '7', '0', 'Question, Hao?', '12', '0', '100', '25', '0', '0', '65590', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '8', '0', 'Yes, Hao - our home is on Shen-zin Su\'s back.', '12', '0', '100', '273', '0', '0', '65591', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '9', '0', 'Liu Lang discovered many things as he explored the world - oh - yes, Hao?', '12', '0', '100', '6', '0', '0', '65592', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '10', '0', 'That\'s a good question. Nobody has spoken to Shen-zin Su for many generations. He only ever spoke to Liu Lang.', '12', '0', '100', '1', '0', '0', '65593', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '11', '0', 'But I am certain that Shen-zin Su knows we are here. And he cares for every one of us!', '12', '0', '100', '66', '0', '0', '65594', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '12', '0', 'Especially Hao! Liu Lang once said, \"Noble is he who always asks questions.\"', '12', '0', '100', '6', '0', '0', '65595', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '13', '0', '\"We should all be like children, for the world is our elder, and has many things to teach us.\"', '12', '0', '100', '1', '0', '0', '65596', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '14', '0', 'Students! Students! Pay attention now.', '12', '0', '100', '22', '0', '0', '65597', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '15', '0', 'Does anyone know how often Liu Lang went back to Pandaria?', '12', '0', '100', '1', '0', '0', '65598', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '16', '0', 'Haha, no Yin. Liu Lang would eat wherever he explored.', '12', '0', '100', '11', '0', '0', '65599', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '17', '0', 'He returned to the main continent of Pandaria once every five years.', '12', '0', '100', '1', '0', '0', '65600', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '18', '0', 'You are right, Yin. It IS hidden away, behind a cloak of mists.', '12', '0', '100', '274', '0', '0', '65601', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '19', '0', 'Does anyone remember how Liu Lang was always able to find it? Nan?', '12', '0', '100', '6', '0', '0', '65602', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '20', '0', 'That\'s right! Liu Lang always had a way back home. Every five years, he would return, to pick up more explorers.', '12', '0', '100', '1', '0', '0', '65603', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '21', '0', 'Yes Hao! Only the BRAVEST pandaren joined Liu Lang on his turtle to explore the world.', '12', '0', '100', '273', '0', '0', '65604', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '22', '0', 'Shen-zin Su hasn\'t made landfall for a long time. But that hasn\'t stopped some pandaren from exploring, anyway.', '12', '0', '100', '1', '0', '0', '65605', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '23', '0', 'Yes, like Chen and Li Li! They\'re out, exploring the world. Maybe someday you will, too.', '12', '0', '100', '21', '0', '0', '65606', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '24', '0', 'I\'m glad you asked, Yin. Liu Lang explored the world his entire life, and raised many children here on the Wandering Isle.', '12', '0', '100', '1', '0', '0', '65607', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '25', '0', 'Eventually he grew very old, and visited Pandaria one final time.', '12', '0', '100', '1', '0', '0', '65608', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '26', '0', 'But nobody else wanted to go exploring with him. So he left.', '12', '0', '100', '6', '0', '0', '65609', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '27', '0', 'Shen-zin Su has never returned to Pandaria.', '12', '0', '100', '274', '0', '0', '65610', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '28', '0', 'Tired now, Liu Lang said goodbye to Shen-zin Su, his oldest friend.', '12', '0', '100', '1', '0', '0', '65611', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '29', '0', 'Then, Liu Lang went up to the Wood of Staves, carrying with him a bamboo umbrella that he always took on his adventures.', '12', '0', '100', '1', '0', '0', '65612', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '30', '0', 'He opened his umbrella, planted it in the ground, and sat underneath its cool shade.', '12', '0', '100', '6', '0', '0', '65613', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '31', '0', 'He closed his eyes, and became one with the land. And then - do you know what happened?', '12', '0', '100', '2', '0', '0', '65614', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '32', '0', 'His umbrella... sprouted! It grew roots, flowered, and became a tree!', '12', '0', '100', '5', '0', '0', '65615', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '33', '0', 'Well, it\'s true. If you ever go to the Wood of Staves, you can see it.', '12', '0', '100', '1', '0', '0', '65616', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '34', '0', 'Along with the budding staves of all the elders who came before us, growing now into giant trees.', '12', '0', '100', '274', '0', '0', '65617', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '35', '0', 'It\'s not a sad story! Liu Lang himself said, \"Never mourn a life well-lived.\"', '12', '0', '100', '1', '0', '0', '65618', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '36', '0', 'And I think he lived a very very good life. We owe everything we have to Liu Lang, the first pandaren explorer.', '12', '0', '100', '273', '0', '0', '65619', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '37', '0', 'We tell his story, so that he will always be remembered.', '12', '0', '100', '2', '0', '0', '65620', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '38', '0', 'Thank you, Ruolin! That was beautiful.', '12', '0', '100', '21', '0', '0', '65621', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64875', '39', '0', 'Could you sing it once more, for the students who just arrived?', '12', '0', '100', '6', '0', '0', '65622', '0', 'Lorewalker Amai to Lorewalker Ruolin'),
('64879', '0', '0', 'Shen-zin Su!', '12', '0', '100', '1', '0', '0', '65635', '0', 'Yin to Lorewalker Amai'),
('64879', '1', '0', '...Whenever he got hungry?', '12', '0', '100', '1', '0', '0', '65645', '0', 'Yin to Lorewalker Amai'),
('64879', '2', '0', 'But isn\'t Pandaria hidden somewhere? Nobody can find it!', '12', '0', '100', '1', '0', '0', '65646', '0', 'Yin to Lorewalker Amai'),
('64879', '3', '0', 'But we don\'t explore very much anymore, do we?', '12', '0', '100', '1', '0', '0', '65649', '0', 'Yin to Lorewalker Amai'),
('64879', '4', '0', 'Lorewalker! What ever happened to Liu Lang?', '12', '0', '100', '1', '0', '0', '65654', '0', 'Yin to Lorewalker Amai'),
('64879', '5', '0', 'That\'s a sad story!', '12', '0', '100', '1', '0', '0', '65658', '0', 'Yin to Lorewalker Amai'),
('64880', '0', '0', 'What is the song about?', '12', '0', '100', '1', '0', '0', '65634', '0', 'Nan to Lorewalker Amai'),
('64880', '1', '0', 'Sheesh, Hao. Haven\'t you ever paid attention?', '12', '0', '100', '1', '0', '0', '65638', '0', 'Nan to Lorewalker Amai'),
('64880', '2', '0', 'Even Hao?', '12', '0', '100', '6', '0', '0', '65641', '0', 'Nan to Lorewalker Amai'),
('64880', '3', '0', 'Blerch! I\'d rather jump off this bridge.', '12', '0', '100', '1', '0', '0', '65644', '0', 'Nan to Lorewalker Amai'),
('64880', '4', '0', 'Because sea turtles always return to the beach where they were born!', '12', '0', '100', '1', '0', '0', '65647', '0', 'Nan to Lorewalker Amai'),
('64880', '5', '0', 'Like Chen and Li Li Stormstout!', '12', '0', '100', '1', '0', '0', '65650', '0', 'Nan to Lorewalker Amai'),
('64880', '6', '0', 'No you don\'t. It\'s full of trolls.', '12', '0', '100', '1', '0', '0', '65652', '0', 'Nan to Lorewalker Amai'),
('64880', '7', '0', 'What? What?', '12', '0', '100', '1', '0', '0', '65656', '0', 'Nan to Lorewalker Amai'),
('64881', '0', '0', 'Why can\'t I understand any of the words?', '12', '0', '100', '1', '0', '0', '65631', '0', 'Hao to Lorewalker Amai'),
('64881', '1', '0', 'We live on the back of a big turtle?!', '12', '0', '100', '5', '0', '0', '65637', '0', 'Hao to Lorewalker Amai'),
('64881', '2', '0', 'I just thought it was weird that the mountains had flippers!', '12', '0', '100', '1', '0', '0', '65639', '0', 'Hao to Lorewalker Amai'),
('64881', '3', '0', 'Does the turtle know we\'re here?', '12', '0', '100', '1', '0', '0', '65640', '0', 'Hao to Lorewalker Amai'),
('64881', '4', '0', 'Hey!', '12', '0', '100', '1', '0', '0', '65642', '0', 'Hao to Lorewalker Amai'),
('64881', '5', '0', 'Yeah, you should all be more like me.', '12', '0', '100', '1', '0', '0', '65643', '0', 'Hao to Lorewalker Amai'),
('64881', '6', '0', 'Does that mean our moms and dads and grandparents were all explorers, too?', '12', '0', '100', '1', '0', '0', '65648', '0', 'Hao to Lorewalker Amai'),
('64881', '7', '0', 'I want to explore the world!', '12', '0', '100', '1', '0', '0', '65651', '0', 'Hao to Lorewalker Amai'),
('64881', '8', '0', 'Oh. Well, forget it then.', '12', '0', '100', '1', '0', '0', '65653', '0', 'Hao to Lorewalker Amai'),
('64881', '9', '0', 'What?', '12', '0', '100', '1', '0', '0', '65655', '0', 'Hao to Lorewalker Amai'),
('64881', '10', '0', 'That\'s un-possible!', '12', '0', '100', '1', '0', '0', '65657', '0', 'Hao to Lorewalker Amai');

DELETE FROM `creature_text` WHERE `creatureID` IN (55595,64506,55744);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('55595', '0', '0', 'Dafeng! What\'s wrong? Why are you hiding back here?', '12', '0', '100', '1', '0', '27403', '54362', '0', 'Aysa Cloudsinger to Player'),
('64506', '0', '0', 'That\'s the way to do it!', '12', '0', '100', '0', '0', '27380', '64766', '0', 'Aysa Cloudsinger to Zhao-Ren'),
('64506', '1', '0', 'You\'ve done it!  Now quickly, lets attack it while it\'s grounded.', '12', '0', '100', '0', '0', '27381', '64767', '0', 'Aysa Cloudsinger to Zhao-Ren'),
('64506', '2', '0', 'It\'s down!  Let\'s finish it off.', '12', '0', '100', '0', '0', '27382', '64768', '0', 'Aysa Cloudsinger to Zhao-Ren'),
('55744', '0', '0', 'Wait!', '12', '0', '100', '5', '0', '27400', '54355', '0', 'Aysa Cloudsinger to Player'),
('55744', '1', '0', 'We need to wait for the winds to settle, then make a break for the cover of the far hallway.', '12', '0', '100', '1', '0', '27401', '54356', '0', 'Aysa Cloudsinger to Player'),
('55744', '2', '0', 'Wait for another opening. I\'ll meet you on the far side.', '12', '0', '100', '1', '0', '27402', '54357', '0', 'Aysa Cloudsinger to Player');

DELETE FROM `creature_text` WHERE `creatureID` IN (56159,55672);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('56159', '0', '0', 'Come child. We have one final journey to take together before your training is complete.', '12', '0', '100', '1', '0', '27797', '55520', '0', 'Master Shang Xi to Player'),
('56159', '1', '0', 'Beyond the Elders\' Path lies the Wood of Staves, a sacred place that only the worthy may enter.', '12', '0', '100', '1', '0', '27800', '55521', '0', 'Master Shang Xi to Player'),
('56159', '2', '0', 'Of the many ways to prove your worth, I require the simplest of you now. I must know that you will fight for our people. I must know that you can keep them safe.', '12', '0', '100', '1', '0', '27801', '55522', '0', 'Master Shang Xi to Player'),
('56159', '3', '0', 'Defeat the Guardian of the Elders, and we may pass.', '12', '0', '100', '1', '0', '27802', '55523', '0', 'Master Shang Xi to Player'),
('56159', '4', '0', 'You\'ve become strong indeed, child. This is good. You will need that strength soon.', '12', '0', '100', '1', '0', '27803', '56484', '0', 'Master Shang Xi to Player'),
('55672', '0', '0', 'And here we are. Help me with a couple small tasks while I prepare, if you would.', '12', '0', '100', '1', '0', '27805', '56485', '0', 'Master Shang Xi to Player');

DELETE FROM `creature_text` WHERE `creatureID` IN (56686);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('56686', '0', '0', 'For 3,000 years, we have passed the knowledge of our people down. Elder to youth. Master to student.', '12', '0', '100', '1', '0', '27807', '55528', '0', 'Master Shang Xi to Player'),
('56686', '1', '0', 'Every elder reaches the day where he must pass on and plant his stave with the staves of his ancestors. Today is the day when my staff joins these woods.', '12', '0', '100', '1', '0', '27808', '55529', '0', 'Master Shang Xi to Player'),
('56686', '2', '0', '$p, our people have lived the wholes of their lives on this great turtle, Shen-zin Su, but not in hundreds of years has anyone spoken to him.', '12', '0', '100', '1', '0', '27809', '55530', '0', 'Master Shang Xi to Player'),
('56686', '3', '0', 'Now Shen-zin Su is ill, and we are all in danger. With the help of the elements, you will break the silence. You will speak to him.', '12', '0', '100', '1', '0', '27810', '55531', '0', 'Master Shang Xi to Player'),
('56686', '4', '0', 'Aysa and Ji have retrieved the spirits and brought them here. You are to go with them, speak to the great Shen-zin Su, and do what must be done to save our people.', '12', '0', '100', '1', '0', '27811', '55532', '0', 'Master Shang Xi to Player'),
('56686', '5', '0', 'You\'ve come far, my young student. I see within you a great hero. I leave the fate of this land to you.', '12', '0', '100', '396', '0', '27812', '55533', '0', 'Master Shang Xi to Player');

DELETE FROM `creature_text` WHERE `creatureID` IN (56662, 56663);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('56662', '0', '0', 'We\'re ready to go whenever you are, $n.', '12', '0', '100', '1', '0', '27428', '55549', '0', 'Aysa Cloudsinger to Player'),
('56662', '1', '0', 'Don\'t listen to him.  We\'ve got work to do.', '12', '0', '100', '1', '0', '27430', '55553', '0', 'Aysa Cloudsinger to Player'),
('56662', '2', '0', 'Hop in.', '12', '0', '100', '1', '0', '27429', '55551', '0', 'Aysa Cloudsinger to Player'),
('56663', '0', '0', 'Or if you want to wander the woods a while, Aysa and I can hang out here.  You know... just the two of us.', '12', '0', '100', '1', '0', '27296', '55552', '0', 'Ji Firepaw to Player');

DELETE FROM `creature_text` WHERE `creatureID` IN (56660, 56661, 56676);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
('56660', '0', '0', '$p, where\'s Master Shang?', '12', '0', '100', '6', '0', '27297', '0', '55554', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('56660', '1', '0', 'Bah, let a pandaren hope, would you?  I\'m going to miss the old man.', '12', '0', '100', '1', '0', '27298', '0', '55556', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('56660', '2', '0', 'When am I not respectful?  You hurt me, Aysa.', '12', '0', '100', '6', '0', '27299', '0', '55561', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('56660', '3', '0', 'A thorn?  And I left my tweezers at home.', '12', '0', '100', '6', '0', '27300', '0', '55574', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('56660', '4', '0', 'How could such a thing cause pain to something so large?', '12', '0', '100', '6', '0', '27301', '0', '55575', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('56660', '5', '0', 'Are you seeing what I\'m seeing?!  Is that a boat?!', '12', '0', '100', '5', '0', '27302', '0', '55577', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('56660', '6', '0', 'And those aren\'t pandaren down there.  They\'ve got no fur.', '12', '0', '100', '1', '0', '27303', '0', '55579', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('56661', '0', '0', '...Ji, they were in the Wood of Staves.  You know where Master Shang is now.', '12', '0', '100', '1', '0', '27431', '0', '55555', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '1', '0', 'Ji, be respectful when we speak to Shen-zin Su.', '12', '0', '100', '1', '0', '27432', '0', '55560', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '2', '0', 'I might if you embarrass us.', '12', '0', '100', '1', '0', '27433', '0', '55562', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '3', '0', 'Shen-zin Su, we are the descendants of Liu Lang.  We\'ve sensed your pain, and we want to help.', '14', '0', '100', '1', '0', '27434', '0', '55563', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '4', '0', 'What ails you Shen-zin Su?  What can we do?', '14', '0', '100', '6', '0', '27435', '0', '55564', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '5', '0', 'Of course, Shen-zin Su!  But your shell is large, and I do not know where this thorn could be.', '14', '0', '100', '1', '0', '27436', '0', '55571', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '6', '0', 'We will find it, and we will remove it.  You have our word!', '14', '0', '100', '1', '0', '27437', '0', '55573', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '7', '0', 'We\'ll know soon enough.', '12', '0', '100', '1', '0', '27438', '0', '55576', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '8', '0', 'It is a boat... a whole airship!  That\'s a bigger thorn than I was expecting.', '12', '0', '100', '1', '0', '27439', '0', '55578', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '9', '0', 'Someone has crashed into our island.  Removing this thorn may be more complicated than we thought.', '12', '0', '100', '1', '0', '27440', '0', '55581', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56661', '10', '0', 'We should let Elder Shaopai know and then plan our next move.', '12', '0', '100', '1', '0', '27441', '0', '55582', '0', 'Aysa Cloudsinger to Shang Xi\'s Hot Air Balloon'),
('56676', '0', '0', 'I am in pain, but it warms my heart that Liu Lang\'s grandchildren have not forgotten me.', '12', '0', '100', '0', '0', '27822', '0', '55550', '0', 'Shen-zin Su to Player'),
('56676', '1', '0', 'There is a thorn in my side.  I cannot remove it.', '12', '0', '100', '0', '0', '27823', '0', '55568', '0', 'Shen-zin Su to Player'),
('56676', '2', '0', 'The pain is unbearable, and I can no longer swim straight.', '12', '0', '100', '0', '0', '27824', '0', '55569', '0', 'Shen-zin Su to Player'),
('56676', '3', '0', 'Please grandchildren, can you remove this thorn?  I cannot do so on my own.', '12', '0', '100', '0', '0', '27825', '0', '55570', '0', 'Shen-zin Su to Player'),
('56676', '4', '0', 'It is in the forest where your feet do not walk.  Continue along the mountains and you will find it.', '12', '0', '100', '0', '0', '27826', '0', '55572', '0', 'Shen-zin Su to Player'),
('56676', '5', '0', 'Thank you, grandchildren.', '12', '0', '100', '0', '0', '27827', '0', '63407', '0', 'Shen-zin Su to Player');

DELETE FROM `creature_text` WHERE `creatureID` IN (59986, 59988, 60042, 55943, 60900, 56236, 56416, 60729, 60741, 60770,60877,60834,60878,56418,60851,60852);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`,`BroadcastTextId`, `TextRange`, `comment`) VALUES
('59986', '0', '0', '$n\'s here. Let\'s go.', '12', '0', '100', '432', '0', '27420', 0, '59481', '0', 'Aysa Cloudsinger to Player'),
('59986', '1', '0', 'Wha...', '12', '0', '100', '0', '0', '27421', 0, '59495', '0', 'Aysa Cloudsinger to Player'),
('59986', '2', '0', 'The gate is jammed.', '12', '0', '100', '274', '0', '27422', 0, '59511', '0', 'Aysa Cloudsinger to Player'),
('59988', '0', '0', 'Let me try.', '12', '0', '100', '5', '0', '27339', 0, '59513', '0', 'Ji to Aysa'),
('59988', '1', '0', 'Did they prop this door up against a boulder?  It won\'t budge!', '12', '0', '100', '5', '0', '27340', 0, '59515', '0', 'Ji to Aysa'),
('59988', '2', '0', 'Well done, Jojo!', '12', '0', '100', '5', '0', '27341', 0, '59521', '0', 'Ji to Jojo'),
('59988', '3', '0', 'We need to dislodge that ship, Korga.  If we help your crewmates, can you help us?', '12', '0', '100', '1', '0', '27333', '0', '59584', '0', 'Ji Firepaw to Player'),
('59988', '4', '0', 'Well, we\'ve got a master person-finder here, eh $p?  We\'re on it.', '12', '0', '100', '1', '0', '27334', '0', '59586', '0', 'Ji Firepaw to Player'),
('60042', '0', '0', 'Wei, are these friends of yours?', '12', '0', '100', '6', '0', '28120', '0', '54956', '0', 'Korga Strongmane to Player'),
('60042', '1', '0', 'Korga Strongmane, once prisoner of the Alliance, now free and woefully unarmed tauren. Good to meet you, pandaren.', '12', '0', '100', '66', '0', '28121', '0', '59555', '0', 'Korga Strongmane to Player'),
('60042', '2', '0', 'Gladly, my new friend. Our engineer is still in the wilds though - we\'ll need to rescue him first.', '12', '0', '100', '1', '0', '28122', '0', '59585', '0', 'Korga Strongmane to Ji'),
('55943', '0', '0', 'Never met them before in my life. Pandaren don\'t really come in any bad flavors though.', '12', '0', '100', '0', '0', '28090', '0', '59554', '0', 'Wei Palerage to Player'),
('60900', '0', '0', 'Let\'s go find this engineer.  Maybe getting this thorn removed won\'t be as hard as we thought.', '12', '0', '100', '396', '0', '27335', '0', '60379', '0', 'Ji Firepaw to Korga'),
('56236', '0', '0', 'I... I am in your debt.', '12', '0', '100', '0', '0', '0', '0', '55139', '0', 'Injured Sailor to Player'),
('56236', '0', '1', 'I\'m... alive?  Thank you... thank you so much!', '12', '0', '100', '18', '0', '0', '0', '63840', '0', 'Injured Sailor to Player'),
('56236', '0', '2', 'I can... I can barely breathe.  I\'m alive thanks to you.', '12', '0', '100', '18', '0', '0', '0', '64337', '0', 'Injured Sailor to Player'),
('56236', '0', '3', 'I\'m alive thanks only to you... I won\'t forget this.', '12', '0', '100', '18', '0', '0', '0', '64342', '0', 'Injured Sailor to Player'),
('56236', '0', '4', 'I thought that was it... I thought I was going to die.  Thank you, stranger.', '12', '0', '100', '18', '0', '0', '0', '64344', '0', 'Injured Sailor to Player'),
('56236', '0', '5', 'I owe you my life.', '12', '0', '100', '2', '0', '0', '0', '64348', '0', 'Injured Sailor to Player'),
('56236', '0', '6', 'Thank you for the timely rescue, hero.', '12', '0', '100', '2', '0', '0', '0', '64355', '0', 'Injured Sailor to Player'),
('56416', '0', '0', 'Thank Shen-zin Su that you\'re here.  I could use your help!', '12', '0', '100', '0', '0', '27384', '0', '64848', '0', 'Aysa Cloudsinger to Vordraka, the Deep Sea Nightmare'),
('56416', '1', '0', 'Get clear when it raises its weapon, it\'s even stronger than it looks.', '12', '0', '100', '0', '0', '27385', '0', '64849', '0', 'Aysa Cloudsinger to Vordraka, the Deep Sea Nightmare'),
('56416', '2', '0', 'It\'s calling allies!  I\'ll keep him busy while you handle them.', '12', '0', '100', '0', '0', '27386', '0', '64850', '0', 'Aysa Cloudsinger to Vordraka, the Deep Sea Nightmare'),
('56416', '3', '0', 'We\'re wearing him down.  Keep it up!', '12', '0', '100', '0', '0', '27387', '0', '64852', '0', 'Aysa Cloudsinger to Vordraka, the Deep Sea Nightmare'),
('56416', '4', '0', 'I don\'t know what I would have done without you.  It\'s good that you came.', '12', '0', '100', '0', '0', '27388', '0', '64853', '0', 'Aysa Cloudsinger to Vordraka, the Deep Sea Nightmare'),
('60729', '0', '0', 'Ji may kill Shen-zin Su if we let him go through with this! Come with me, $p, quickly!', '12', '0', '100', '5', '0', '27412', '0', '55140', '0', 'Aysa Cloudsinger to Player'),
('60729', '1', '0', 'Ji, stop! This is reckless and stupid.', '12', '0', '100', '5', '0', '27413', '0', '60188', '0', 'Aysa Cloudsinger to Player'),
('60729', '2', '0', 'If you stop this, then maybe we can come up with one.', '12', '0', '100', '274', '0', '27414', '0', '60190', '0', 'Aysa Cloudsinger to Player'),
('60729', '3', '0', 'Doing THIS risks everything!', '12', '0', '100', '5', '0', '27415', '0', '60192', '0', 'Aysa Cloudsinger to Player'),
('60729', '4', '0', 'Ji... if this is what you must do, I will not stop you, but we could lose everything. I hope you\'re right.', '12', '0', '100', '1', '0', '27416', '0', '60194', '0', 'Aysa Cloudsinger to Player'),
('60729', '5', '0', 'Aysa sighs.', '16', '0', '100', '274', '0', '0', '0', '60211', '0', 'Aysa Cloudsinger to Player'),
('60741', '0', '0', 'Aysa, this is our only option. We blow the ship free, then we heal his wound. We have no other solution.', '12', '0', '100', '1', '0', '27329', '0', '60189', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('60741', '1', '0', 'So we just wait until we think of something? Shen-zin Su is dying! Doing nothing risks everything!', '12', '0', '100', '6', '0', '27330', '0', '60191', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('60741', '2', '0', 'I\'d rather die knowing that at least we tried.', '12', '0', '100', '1', '0', '27331', '0', '60193', '0', 'Ji Firepaw to Aysa Cloudsinger'),
('60770', '0', '0', 'Thank you for the help. I\'ll go help with the wound.', '12', '0', '100', '396', '0', '0', '0', '60248', '0', 'Horde Druid to Player'),
('60770', '0', '1', 'I\'m heading to the wound. Try to keep these beasts off of me.', '12', '0', '100', '396', '0', '0', '0', '60342', '0', 'Horde Druid to Player'),
('60770', '0', '2', 'You\'re a life-saver. I\'ll do everything I can to heal the wound.', '12', '0', '100', '396', '0', '0', '0', '60343', '0', 'Horde Druid to Player'),
('60770', '0', '3', 'I thought I was done for. Thank you!', '12', '0', '100', '396', '0', '0', '0', '60344', '0', 'Horde Druid to Player'),
('60770', '0', '4', 'If all pandaren are like you, I think you may have made some new allies!', '12', '0', '100', '396', '0', '0', '0', '60345', '0', 'Horde Druid to Player'),
('60770', '0', '5', 'You handle the beasts, we\'ll handle the wound.', '12', '0', '100', '396', '0', '0', '0', '60346', '0', 'Horde Druid to Player'),
('60770', '0', '6', 'Keep these creatures off of us while we perform our healing.', '12', '0', '100', '396', '0', '0', '0', '60347', '0', 'Horde Druid to Player'),
('60770', '0', '7', 'I\'d stand with you any day.', '12', '0', '100', '396', '0', '0', '0', '60348', '0', 'Horde Druid to Player'),
('60834', '0', '0', 'Thank you for the help. I\'ll go help with the wound.', '12', '0', '100', '396', '0', '0', '0', '60248', '0', 'Horde Druid to 60848'),
('60834', '0', '1', 'I\'m heading to the wound. Try to keep these beasts off of me.', '12', '0', '100', '396', '0', '0', '0', '60342', '0', 'Horde Druid to 60848'),
('60834', '0', '2', 'You\'re a life-saver. I\'ll do everything I can to heal the wound.', '12', '0', '100', '396', '0', '0', '0', '60343', '0', 'Horde Druid to 60848'),
('60834', '0', '3', 'I thought I was done for. Thank you!', '12', '0', '100', '396', '0', '0', '0', '60344', '0', 'Horde Druid to 60848'),
('60834', '0', '4', 'If all pandaren are like you, I think you may have made some new allies!', '12', '0', '100', '396', '0', '0', '0', '60345', '0', 'Horde Druid to 60848'),
('60834', '0', '5', 'You handle the beasts, we\'ll handle the wound.', '12', '0', '100', '396', '0', '0', '0', '60346', '0', 'Horde Druid to 60848'),
('60834', '0', '6', 'Keep these creatures off of us while we perform our healing.', '12', '0', '100', '396', '0', '0', '0', '60347', '0', 'Horde Druid to 60848'),
('60834', '0', '7', 'I\'d stand with you any day.', '12', '0', '100', '396', '0', '0', '0', '60348', '0', 'Horde Druid to 60848'),
('60877', '0', '0', 'Thank you for the help. I\'ll go help with the wound.', '12', '0', '100', '396', '0', '0', '0', '60248', '0', 'Alliance Priest to Player'),
('60877', '0', '1', 'I\'m heading to the wound. Try to keep these beasts off of me.', '12', '0', '100', '396', '0', '0', '0', '60342', '0', 'Alliance Priest to Player'),
('60877', '0', '2', 'You\'re a life-saver. I\'ll do everything I can to heal the wound.', '12', '0', '100', '396', '0', '0', '0', '60343', '0', 'Alliance Priest to Player'),
('60877', '0', '3', 'I thought I was done for. Thank you!', '12', '0', '100', '396', '0', '0', '0', '60344', '0', 'Alliance Priest to Player'),
('60877', '0', '4', 'If all pandaren are like you, I think you may have made some new allies!', '12', '0', '100', '396', '0', '0', '0', '60345', '0', 'Alliance Priest to Player'),
('60877', '0', '5', 'You handle the beasts, we\'ll handle the wound.', '12', '0', '100', '396', '0', '0', '0', '60346', '0', 'Alliance Priest to Player'),
('60877', '0', '6', 'Keep these creatures off of us while we perform our healing.', '12', '0', '100', '396', '0', '0', '0', '60347', '0', 'Alliance Priest to Player'),
('60877', '0', '7', 'I\'d stand with you any day.', '12', '0', '100', '396', '0', '0', '0', '60348', '0', 'Alliance Priest to Player'),
('60878', '0', '0', 'Thank you for the help. I\'ll go help with the wound.', '12', '0', '100', '396', '0', '0', '0', '60248', '0', 'Alliance Priest to 60848'),
('60878', '0', '1', 'I\'m heading to the wound. Try to keep these beasts off of me.', '12', '0', '100', '396', '0', '0', '0', '60342', '0', 'Alliance Priest to 60848'),
('60878', '0', '2', 'You\'re a life-saver. I\'ll do everything I can to heal the wound.', '12', '0', '100', '396', '0', '0', '0', '60343', '0', 'Alliance Priest to 60848'),
('60878', '0', '3', 'I thought I was done for. Thank you!', '12', '0', '100', '396', '0', '0', '0', '60344', '0', 'Alliance Priest to 60848'),
('60878', '0', '4', 'If all pandaren are like you, I think you may have made some new allies!', '12', '0', '100', '396', '0', '0', '0', '60345', '0', 'Alliance Priest to 60848'),
('60878', '0', '5', 'You handle the beasts, we\'ll handle the wound.', '12', '0', '100', '396', '0', '0', '0', '60346', '0', 'Alliance Priest to 60848'),
('60878', '0', '6', 'Keep these creatures off of us while we perform our healing.', '12', '0', '100', '396', '0', '0', '0', '60347', '0', 'Alliance Priest to 60848'),
('60878', '0', '7', 'I\'d stand with you any day.', '12', '0', '100', '396', '0', '0', '0', '60348', '0', 'Alliance Priest to 60848'),
('56418', '0', '0', 'There are healers under some of the wreckage!  Get them free.', '14', '0', '100', '0', '0', '27285', '0', '66060', '0', 'Ji Firepaw'),
('56418', '0', '1', 'Find the healers and get them free of the fight.  We need them here at the wound!', '14', '0', '100', '0', '0', '27286', '0', '66061', '0', 'Ji Firepaw'),
('56418', '0', '2', 'Stay close and keep these healers safe.  Our lives depend on it.', '14', '0', '100', '0', '0', '27287', '0', '66062', '0', 'Ji Firepaw'),
('56418', '0', '3', 'If we lose the healers, Shen-zin Su dies, and all of us with him!  Keep them safe.', '14', '0', '100', '0', '0', '27288', '0', '66063', '0', 'Ji Firepaw'),
('60851', '0', '0', 'We\'ll cover this front. You keep my priests safe.', '12', '0', '100', '396', '0', '27503', '0', '59720', '0', 'Delora Lionheart to Player'),
('60852', '0', '0', 'We stand by your side, friend.  This battle is not yours alone.', '12', '0', '100', '6', '0', '28119', '0', '59719', '0', 'Korga Strongmane to Player');

-- ============================================
-- Creature Text for New Allies Quest
-- ============================================

DELETE FROM creature_text WHERE creatureid IN (60888, 60889);
INSERT INTO creature_text (creatureid,groupid,id,TEXT,TYPE,LANGUAGE,probability,emote,duration,COMMENT,sound,BroadcastTextId) VALUES
-- Koga Strongmane dialogue
(60888, 0, 0, 'I bear your presence only as a kindness to our new allies. Don\'t push me, human.', 12, 0, 100, 0, 0, 'Koga Strongmane - New Allies Quest', 0, 60359),

-- Delora Lionheart dialogue  
(60889, 0, 0, 'Stand down, tauren, before I put you back in chains.', 12, 0, 100, 396, 0, 'Delora Lionheart - New Allies Quest', 0, 60623);

-- ============================================
-- A New Fate Quest (31450) - Creature Text Inserts
-- ============================================

DELETE FROM creature_text WHERE creatureid IN (56013, 57721, 57720);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`,`BroadcastTextId`, `TextRange`, `comment`) VALUES
-- Spirit of Master Shang Xi dialogue
('56013', '0', '0', 'You\'ve all accomplished a great thing in saving Shen-zin Su. You do us all proud.', '12', '0', '100', '1', '0', '27784', '0', '60632', '0', 'Spirit of Master Shang Xi to Player'),
('56013', '1', '0', 'It seems your journeys are not done. These new allies of ours come from a broken world that could use our help.', '12', '0', '100', '1', '0', '27785', '0', '60633', '0', 'Spirit of Master Shang Xi to Player'),
('56013', '2', '0', 'What of you, Ji? Will you join the Horde in their journey back?', '12', '0', '100', '6', '0', '27786', '0', '60629', '0', 'Spirit of Master Shang Xi to Player'),
('56013', '3', '0', 'And you, my young student? Where will you go?', '12', '0', '100', '6', '0', '27787', '0', '60631', '0', 'Spirit of Master Shang Xi to Player'),
-- Ji Firepaw dialogue
('57720', '0', '0', 'Yes... perhaps that is for the best. I like what I\'ve seen of them, and it sounds as though their world could use my help.', '12', '0', '100', '273', '0', '27305', '0', '60630', '0', 'Ji Firepaw to Player'),
-- Aysa Cloudsinger dialogue
('57721', '0', '0', 'Master Shang Xi, I would like to accompany the Alliance back to their home.', '12', '0', '100', '1', '0', '27405', '0', '60628', '0', 'Aysa Cloudsinger to Player');

-- Ji at the Morning Breeze Docks
DELETE FROM creature_text WHERE creatureid IN (55583,65558);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`, `BroadcastTextId`, `TextRange`, `comment`) VALUES 
('55583', '0', '0', 'Ji Firepaw warmly hugs you back.', '16', '0', '100', '0', '0', '0', '0', '64831', '0', 'Ji Firepaw hugs player'),
('55583', '1', '0', 'Aysa? I don\'t know what to say to her. Should I tell her she\'s gorgeous, or would she find that creepy? Maybe I could tell her I admire her poise - but then she might think I don\'t have any personality!', '12', '0', '100', '0', '0', '0', '0', '62477', '0', 'Ji Firepaw to player'),
-- Ji/Monk Guardian 
(65558, 0, 0, 'Let\'s tackle this one together!', 12, 0, 100, 5, 0, 27320, 0, 60609, 0, 'Ji Firepaw to Player'),
(65558, 1, 0, 'I like the way you fight!', 12, 0, 100, 5, 0, 27322, 0, 60610, 0, 'Ji Firepaw to Player'),
(65558, 1, 1, 'He had that one coming.', 12, 0, 100, 273, 0, 27323, 0, 60611, 0, 'Ji Firepaw to Player'),
(65558, 1, 2, 'Ouch! That one looked painful!', 12, 0, 100, 5, 0, 27324, 0, 60612, 0, 'Ji Firepaw to Player'),
(65558, 1, 3, 'You make this look easy.', 12, 0, 100, 1, 0, 27325, 0, 60613, 0, 'Ji Firepaw to Player'),
(65558, 1, 4, 'They never stood a chance.', 12, 0, 100, 1, 0, 27326, 0, 60614, 0, 'Ji Firepaw to Player'),
(65558, 1, 5, 'You\'ve got this handled.', 12, 0, 100, 273, 0, 27327, 0, 60615, 0, 'Ji Firepaw to Player'),
(65558, 1, 6, 'I need to fight by you more often.', 12, 0, 100, 1, 0, 27328, 0, 60616, 0, 'Ji Firepaw to Player'),
(65558, 2, 0, 'Let\'s do this, monkeyface!', 12, 0, 100, 5, 0, 27318, 0, 60619, 0, 'Ji Firepaw to Player'),
(65558, 3, 0, 'That all you\'ve got?!', 12, 0, 100, 5, 0, 27316, 0, 60620, 0, 'Ji Firepaw to Player'),
(65558, 4, 0, 'This monkey\'s about to get slapped!', 12, 0, 100, 5, 0, 27317, 0, 60621, 0, 'Ji Firepaw to Player'),
(65558, 5, 0, 'And he\'s down for the count! Good going.', 12, 0, 100, 5, 0, 27315, 0, 60622, 0, 'Ji Firepaw to Player'),
(65558, 6, 0, 'See you at the dock!', 12, 0, 100, 0, 0, 27319, 0, 60618, 0, 'Ji Firepaw to Player');

-- Jojo spawn pillar quest
DELETE FROM creature_text WHERE creatureid IN (57692);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`, `BroadcastTextId`, `TextRange`, `comment`) VALUES 
(57692, 0, 0, 'This is magnificent!  I\'ve never seen craftsmanship so fine.', 12, 0, 100, 1, 0, 0, 0, 56363, 0, 'Jojo Ironbrow to Player'),
(57692, 1, 0, 'There is only one thing to do.  I must smash it!  Once and for all, all shall know the power of my mighty brow.', 12, 0, 100, 1, 0, 0, 0, 56361, 0, 'Jojo Ironbrow to Player'),
(57692, 2, 0, 'Oh... my head... it hurts so badly!  I\'ve... the pillar must contain enormous power... perhaps stronger even than my brow...', 12, 0, 100, 18, 0, 0, 0, 56362, 0, 'Jojo Ironbrow to Player'),
(57692, 3, 0, 'I\'m... I\'m just going to lie down a while... until this headache goes away.', 12, 0, 100, 0, 0, 0, 0, 56364, 0, 'Jojo Ironbrow to Player');

-- Delora Lionheart
DELETE FROM creature_text WHERE creatureid IN (55944);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `SoundPlayType`, `BroadcastTextId`, `TextRange`, `comment`) VALUES 
(55944, 0, 0, 'We need more healers at the tents. Recall the priests from the west.', 14, 0, 100, 22, 0, 27508, 0, 60625, 0, 'Delora Lionheart'),
(55944, 1, 0, 'Hold the line, sailors! Your brothers depend on you!', 14, 0, 100, 22, 0, 27505, 0, 59721, 0, 'Delora Lionheart'),
(55944, 2, 0, 'Tend to the wounded! This isn''t over yet.', 14, 0, 100, 22, 0, 27506, 0, 59722, 0, 'Delora Lionheart'),
(55944, 3, 0, 'We have men in that wreckage! Get more men out there recovering the wounded.', 14, 0, 100, 22, 0, 27507, 0, 60624, 0, 'Delora Lionheart');
