-- Mardum Creature Text
DELETE FROM `creature_text` WHERE `creatureID` IN (98484,98486,98497,98460,95226,93112,96884,93759,94654,93221,95048,93716,97034,96494,102726,96499,
102724,97706,97059,96402,96277,97057,102923,96888,100549,100545,100543,96279,96280,97058,96877,97370,96503,98711,98986,97676,96653,97297,93802,97303,
97244,95046,98483,102714,96400,98456,98457,98458,98459,99919);
DELETE FROM `creature_text` WHERE `creatureID` IN (98229) AND `GroupID` IN (2,3);
DELETE FROM `creature_text` WHERE `creatureID` IN (93127) AND `GroupID` IN (2,3,4);
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
(98456, 0, 0, 'My scythe will compel them.', 12, 0, 100, 0, 0, 55002, 100204, 0, 'Allari the Souleater to Player'),
(98456, 0, 1, 'The Scythe of Souls will cut you down!', 12, 0, 100, 0, 0, 55001, 100205, 0, 'Allari the Souleater to Player'),
(98456, 0, 2, 'We should capture and interrogate some of these demons.', 12, 0, 100, 0, 0, 55004, 100202, 0, 'Allari the Souleater to Player'),
(98456, 0, 3, 'Where is the keystone, demon?', 12, 0, 100, 0, 0, 55003, 100203, 0, 'Allari the Souleater to Player'),

(98457, 0, 0, 'The fel energy is everywhere. It\'s hard to resist.', 12, 0, 100, 0, 0, 55099, 100208, 0, 'Cyana Nightglaive to Player'),
(98457, 0, 1, 'There are too many of them!', 12, 0, 100, 0, 0, 55100, 198175, 0, 'Cyana Nightglaive to Player'),
(98457, 0, 2, 'Did we bring enough of us?', 12, 0, 100, 0, 0, 55097, 100206, 0, 'Cyana Nightglaive to Player'),
(98457, 0, 3, 'Lord Illidan chose you to lead. I follow.', 12, 0, 100, 0, 0, 55098, 100207, 0, 'Cyana Nightglaive to Player'),

(98458, 0, 0, 'I\'ll scout forward after this and find the keystone.', 12, 0, 100, 0, 0, 55240, 100212, 0, 'Jace Darkweaver to Player'),
(98458, 0, 1, 'We should gather intel on their leaders.', 12, 0, 100, 0, 0, 55238, 100210, 0, 'Jace Darkweaver to Player'),
(98458, 0, 2, 'I\'m glad you\'re leading us, $n.', 12, 0, 100, 0, 0, 55241, 100213, 0, 'Jace Darkweaver to Player'),
(98458, 0, 3, 'We must find the Sargerite Keystone.', 12, 0, 100, 0, 0, 55239, 100211, 0, 'Jace Darkweaver to Player'),

(98459, 0, 0, 'I have some ideas for how to proceed.', 12, 0, 100, 0, 0, 55269, 100219, 0, 'Kayn Sunfury to Player'),
(98459, 0, 1, 'You know, I should be in command.', 12, 0, 100, 0, 0, 55280, 100220, 0, 'Kayn Sunfury to Player'),
(98459, 0, 2, 'Lord Illidan places a lot of faith in you.', 12, 0, 100, 0, 0, 55279, 100216, 0, 'Kayn Sunfury to Player'),
(98459, 0, 3, 'My gut tells me the keystone is up in that volcano.', 12, 0, 100, 0, 0, 55274, 100217, 0, 'Kayn Sunfury to Player'),

(98460, 0, 0, 'Hah! Racking up the kills.', 12, 0, 100, 0, 0, 55288, 100222, 0, 'Kor\'vas Bloodthorn to Player'),
(98460, 0, 1, 'Having fun? I am!', 12, 0, 100, 0, 0, 55287, 100223, 0, 'Kor\'vas Bloodthorn to Player'),
(98460, 0, 2, 'What\'s next, $n?', 12, 0, 100, 0, 0, 55286, 100224, 0, 'Kor\'vas Bloodthorn to Player'),
(98460, 0, 3, 'Just point me in the right direction.', 12, 0, 100, 0, 0, 55289, 100225, 0, 'Kor\'vas Bloodthorn to Player'),

(99919, 0, 0, 'You and me to the very end, $n.', 12, 0, 100, 0, 0, 55349, 101667, 0, 'Sevis Brightflame to Player'),
(99919, 0, 1, 'For Lord Illidan! For the Illidari!', 12, 0, 100, 0, 0, 55350, 101666, 0, 'Sevis Brightflame to Player'),
(99919, 0, 2, 'You will be the one dying today, demon!', 12, 0, 100, 0, 0, 55348, 101664, 0, 'Sevis Brightflame to Player'),
(99919, 0, 3, 'I\'ve been looking forward to this for a long time.', 12, 0, 100, 0, 0, 55351, 101665, 0, 'Sevis Brightflame to Player'),

(98483, 0, 0, 'Tasty meats for me to eats.', 12, 0, 100, 0, 0, 55207, 96658, 0, 'Hellish Imp to Player'),
(98483, 0, 1, 'We\'ll feast on your flesh and devour your soul.', 12, 0, 100, 0, 0, 55205, 96656, 0, 'Hellish Imp to Player'),
(98483, 0, 2, 'Another morsel has come to say, hello.', 12, 0, 100, 0, 0, 55203, 96654, 0, 'Hellish Imp to Player'),
(98483, 0, 3, 'Quickly, grab them!', 12, 0, 100, 0, 0, 55202, 96653, 0, 'Hellish Imp to Player'),
(98483, 0, 4, 'Help! Baddies here!', 12, 0, 100, 0, 0, 55204, 96655, 0, 'Hellish Imp to Player'),
(98483, 0, 5, 'Hey! You''re not supposed to be here.', 12, 0, 100, 0, 0, 55206, 96657, 0, 'Hellish Imp to Player'),
(98483, 0, 6, 'I''ll burn your kneecaps off.', 12, 0, 100, 0, 0, 55209, 96660, 0, 'Hellish Imp to Player'),
(98483, 0, 7, 'Warn the Brood Queen!', 12, 0, 100, 0, 0, 55208, 96659, 0, 'Hellish Imp to Player'),

-- female
(102714, 0, 0, 'Your world will be purged!', 12, 0, 100, 0, 0, 56970, 96722, 0, 'Eredar Summoner to Player'), -- BroadcastTextID: 96722 - 129826
(102714, 0, 1, 'Quickly, finish the summons.', 12, 0, 100, 0, 0, 56966, 96718, 0, 'Eredar Summoner to Player'),
(102714, 0, 2, 'For the Brood Queen.', 12, 0, 100, 0, 0, 56969, 96721, 0, 'Eredar Summoner to Player'),
(102714, 0, 3, 'The Legion''s will be done.', 12, 0, 100, 0, 0, 56967, 96719, 0, 'Eredar Summoner to Player'),
(102714, 0, 4, 'Kill the Illidari.', 12, 0, 100, 0, 0, 56968, 96720, 0, 'Eredar Summoner to Player'),
(102714, 0, 5, 'Our ritual is interrupted.', 12, 0, 100, 0, 0, 56971, 96723, 0, 'Eredar Summoner to Player'),
(102714, 0, 6, 'Defend the portal.', 12, 0, 100, 0, 0, 56972, 96724, 0, 'Eredar Summoner to Player'),
(102714, 0, 7, 'In Sargeras''s name.', 12, 0, 100, 0, 0, 56973, 96725, 0, 'Eredar Summoner to Player'),

-- male
(95046, 0, 0, 'Your world will be purged!', 12, 0, 100, 0, 0, 56994, 96722, 0, 'Eredar Summoner to Player'), -- BroadcastTextID: 96722 - 129826
(95046, 0, 1, 'Quickly, finish the summons.', 12, 0, 100, 0, 0, 56990, 96718, 0, 'Eredar Summoner to Player'),
(95046, 0, 2, 'For the Brood Queen.', 12, 0, 100, 0, 0, 56993, 96721, 0, 'Eredar Summoner to Player'),
(95046, 0, 3, 'The Legion''s will be done.', 12, 0, 100, 0, 0, 56991, 96719, 0, 'Eredar Summoner to Player'),
(95046, 0, 4, 'Kill the Illidari.', 12, 0, 100, 0, 0, 56992, 96720, 0, 'Eredar Summoner to Player'),
(95046, 0, 5, 'Our ritual is interrupted.', 12, 0, 100, 0, 0, 56995, 96723, 0, 'Eredar Summoner to Player'),
(95046, 0, 6, 'Defend the portal.', 12, 0, 100, 0, 0, 56996, 96724, 0, 'Eredar Summoner to Player'),
(95046, 0, 7, 'In Sargeras''s name.', 12, 0, 100, 0, 0, 56997, 96725, 0, 'Eredar Summoner to Player'),

(97303, 0, 0, 'Hurry, $n. Use the keystone to activate the portal. We must rejoin the fight at the Black Temple.', 12, 0, 100, 1, 0, 55259, 99013, 0, 'Kayn Sunfury to Player'),

(97244, 0, 0, 'Grab the keystone! Let''s get to the portal down below and back to the Black Temple!', 14, 0, 100, 1, 0, 55268, 102063, 0, 'Kayn Sunfury to Player'),

(93802, 0, 0, '$n! You and your demon hunters are nothing.', 12, 0, 100, 0, 0, 55064, 99826, 0, 'Brood Queen Tyranna to Player'),
(93802, 1, 0, 'The keystone was entrusted to me by Sargeras himself. You will not have it!', 12, 0, 100, 0, 0, 55065, 99827, 0, 'Brood Queen Tyranna to Player'),
(93802, 2, 0, 'None can resist my kiss.', 14, 0, 100, 0, 0, 55068, 103514, 0, 'Brood Queen Tyranna to Player'),
(93802, 3, 0, 'Come forth, my children. Feast upon our enemies.', 14, 0, 100, 0, 0, 55069, 103517, 0, 'Brood Queen Tyranna to Player'),
(93802, 4, 0, '|TInterface\Icons\inv_misc_monsterspidercarapace_01:20|t%s disappears |cFFFF0000|Hspell:197414|h[Into the Shadows]|h|r!', 41, 0, 100, 0, 0, 0, 102140, 0, 'Brood Queen Tyranna to Player'),
(93802, 5, 0, 'My Lord Sargeras, no!!!', 14, 0, 100, 0, 0, 55055, 99012, 0, 'Brood Queen Tyranna to Player'),

(97297, 0, 0, 'I''ll secure the exit portal back to the Black Temple once the others fly up here.', 12, 0, 100, 1, 0, 55096, 100418, 0, 'Cyana Nightglaive to Player'),
(97297, 1, 0, 'Hurry. Kayn has already launched the attack on Tyranna.', 12, 0, 100, 5, 0, 55095, 99829, 0, 'Cyana Nightglaive to Player'),

(96653, 0, 0, 'Good luck to all of you. I will get the rest of us up there, $n.', 12, 0, 100, 0, 0, 55228, 99837, 0, 'Izal Whitemoon to Player'),

(97676, 0, 0, 'Beware, $n. There is a dreadlord inside that Soul Engine.', 12, 0, 100, 0, 0, 55304, 99574, 0, 'Lady S''Theno to Player'),

(98986, 0, 0, 'Get away. You cannot have my tome!', 14, 0, 100, 0, 0, 55338, 100840, 0, 'Prolifica to Player'),
(98986, 1, 0, 'My fel secrets will consume you!', 14, 0, 100, 0, 0, 55340, 103490, 0, 'Prolifica to Player'),
(98986, 2, 0, 'They''re stealing our secrets, my queen...', 14, 0, 100, 0, 0, 55339, 100841, 0, 'Prolifica to Player'),

(98711, 0, 0, 'The imp mother is in that cave, right there.', 12, 0, 100, 0, 0, 55290, 100666, 0, 'Kor''vas Bloodthorn to Player'),
(98711, 1, 0, 'I have to go. Kayn''s called me back to handle something. He probably needs help killing a demon.', 12, 0, 100, 0, 0, 55291, 98845, 0, 'Kor''vas Bloodthorn to Player'),

(96503, 0, 0, 'My thanks. Come, my brothers... back to the battle!', 12, 0, 100, 0, 0, 55076, 99093, 0, 'Coilskar Sea-Caller to Player'),

(97370, 0, 0, 'You cannot have them. They are mine!', 14, 0, 100, 0, 0, 55199, 99071, 0, 'General Volroth to Player'),
(97370, 1, 0, 'My fire will leave only your bones behind.', 14, 0, 100, 0, 0, 55201, 103509, 0, 'General Volroth to Player'),
(97370, 2, 0, 'Impossible!', 14, 0, 100, 0, 0, 55200, 99092, 0, 'General Volroth to Player'),

(96877, 0, 0, 'This demon will fall.', 12, 0, 100, 0, 0, 55040, 99734, 0, 'Ashtongue Stalker to Player'),
(96877, 1, 0, 'The Battlelord sent me.', 12, 0, 100, 0, 0, 55036, 99730, 0, 'Ashtongue Stalker to Player'),
(96877, 1, 1, 'We will destroy the Burning Legion.', 12, 0, 100, 0, 0, 55037, 99731, 0, 'Ashtongue Stalker to Player'),
(96877, 1, 2, 'It is an honor to kill in Lord Illidan''s name.', 12, 0, 100, 0, 0, 55038, 99732, 0, 'Ashtongue Stalker to Player'),
(96877, 1, 3, 'Lord Illidan commands and I follow.', 12, 0, 100, 0, 0, 55039, 99733, 0, 'Ashtongue Stalker to Player'),
(96877, 1, 4, 'I am here to assist you.', 12, 0, 100, 0, 0, 55041, 99735, 0, 'Ashtongue Stalker to Player'),
(96877, 1, 5, 'The Ashtongue serve.', 12, 0, 100, 0, 0, 55042, 99736, 0, 'Ashtongue Stalker to Player'),
(96877, 1, 6, 'The Legion must be stopped.', 12, 0, 100, 0, 0, 55043, 99737, 0, 'Ashtongue Stalker to Player'),

(97058, 0, 0, 'Oh good, another soul for my engine.', 12, 0, 100, 0, 0, 55086, 99575, 0, 'Count Nefarious to Player'),
(97058, 1, 0, 'My swarm will feast on your soul!', 14, 0, 100, 0, 0, 55088, 103510, 0, 'Count Nefarious to Player'),
(97058, 2, 0, '|TInterface\Icons\spell_shadow_carrionswarm:20|t%s begins to cast |cFFFF0000|Hspell:198947|h[Carrion Storm]|h|r!', 41, 0, 100, 0, 0, 0, 103413, 0, 'Count Nefarious to Player'),

(96280, 0, 0, 'Tasty meats for me to eats.', 12, 0, 100, 0, 0, 55207, 96658, 0, 'Volatile Minion to Player'),
(96280, 0, 1, 'We\'ll feast on your flesh and devour your soul.', 12, 0, 100, 0, 0, 55205, 96656, 0, 'Volatile Minion to Player'),
(96280, 0, 2, 'Another morsel has come to say, hello.', 12, 0, 100, 0, 0, 55203, 96654, 0, 'Volatile Minion to Player'),
(96280, 0, 3, 'Quickly, grab them!', 12, 0, 100, 0, 0, 55202, 96653, 0, 'Volatile Minion to Player'),
(96280, 0, 4, 'Help! Baddies here!', 12, 0, 100, 0, 0, 55204, 96655, 0, 'Volatile Minion to Player'),
(96280, 0, 5, 'Hey! You''re not supposed to be here.', 12, 0, 100, 0, 0, 55206, 96657, 0, 'Volatile Minion to Player'),
(96280, 0, 6, 'I''ll burn your kneecaps off.', 12, 0, 100, 0, 0, 55209, 96660, 0, 'Volatile Minion to Player'),
(96280, 0, 7, 'Warn the Brood Queen!', 12, 0, 100, 0, 0, 55208, 96659, 0, 'Volatile Minion to Player'),

(100549, 0, 0, 'I will repay my debt to you.', 12, 0, 100, 0, 0, 56813, 102551, 0, 'Demon Hunter to Player'),
(100549, 0, 1, 'The Burning Legion will fall!', 12, 0, 100, 0, 0, 56814, 102552, 0, 'Demon Hunter to Player'),
(100549, 0, 2, 'I will not let you down.', 12, 0, 100, 0, 0, 56815, 102553, 0, 'Demon Hunter to Player'),
(100549, 0, 3, 'For Lord Illidan!', 12, 0, 100, 0, 0, 56816, 102554, 0, 'Demon Hunter to Player'),
(100549, 0, 4, 'We WILL take the keystone!', 12, 0, 100, 0, 0, 56817, 102555, 0, 'Demon Hunter to Player'),
(100549, 0, 5, 'Die demons!', 12, 0, 100, 0, 0, 56818, 102556, 0, 'Demon Hunter to Player'),
(100549, 0, 6, 'I did not make it this far just to die on this rock.', 12, 0, 100, 0, 0, 56819, 102557, 0, 'Demon Hunter to Player'),
(100545, 0, 0, 'I will repay my debt to you.', 12, 0, 100, 0, 0, 56813, 102551, 0, 'Demon Hunter to Player'),
(100545, 0, 1, 'The Burning Legion will fall!', 12, 0, 100, 0, 0, 56814, 102552, 0, 'Demon Hunter to Player'),
(100545, 0, 2, 'I will not let you down.', 12, 0, 100, 0, 0, 56815, 102553, 0, 'Demon Hunter to Player'),
(100545, 0, 3, 'For Lord Illidan!', 12, 0, 100, 0, 0, 56816, 102554, 0, 'Demon Hunter to Player'),
(100545, 0, 4, 'We WILL take the keystone!', 12, 0, 100, 0, 0, 56817, 102555, 0, 'Demon Hunter to Player'),
(100545, 0, 5, 'Die demons!', 12, 0, 100, 0, 0, 56818, 102556, 0, 'Demon Hunter to Player'),
(100545, 0, 6, 'I did not make it this far just to die on this rock.', 12, 0, 100, 0, 0, 56819, 102557, 0, 'Demon Hunter to Player'),
(100543, 0, 0, 'I will repay my debt to you.', 12, 0, 100, 0, 0, 56813, 102551, 0, 'Demon Hunter to Player'),
(100543, 0, 1, 'The Burning Legion will fall!', 12, 0, 100, 0, 0, 56814, 102552, 0, 'Demon Hunter to Player'),
(100543, 0, 2, 'I will not let you down.', 12, 0, 100, 0, 0, 56815, 102553, 0, 'Demon Hunter to Player'),
(100543, 0, 3, 'For Lord Illidan!', 12, 0, 100, 0, 0, 56816, 102554, 0, 'Demon Hunter to Player'),
(100543, 0, 4, 'We WILL take the keystone!', 12, 0, 100, 0, 0, 56817, 102555, 0, 'Demon Hunter to Player'),
(100543, 0, 5, 'Die demons!', 12, 0, 100, 0, 0, 56818, 102556, 0, 'Demon Hunter to Player'),
(100543, 0, 6, 'I did not make it this far just to die on this rock.', 12, 0, 100, 0, 0, 56819, 102557, 0, 'Demon Hunter to Player'),

(96888, 0, 0, 'The Matron Mother bid me come to help.', 12, 0, 100, 0, 0, 55355, 99747, 0, 'Shivarra Destroyer to Player'),

(102923, 0, 0, 'Don''t worry, mother''s here... Oh my, he''s a big one.', 12, 0, 100, 0, 0, 55321, 99153, 0, 'Matron Mother Malevolence to Player'),

(97057, 0, 0, 'I''ll hammer you into shape.', 14, 0, 100, 0, 0, 55336, 99170, 0, 'Overseer Brutarg to Player'),
(97057, 1, 0, 'Like my new sword? Take a closer look.', 14, 0, 100, 0, 0, 55335, 103494, 0, 'Overseer Brutarg to Player'),
(97057, 2, 0, 'Stupid, tiny things...', 14, 0, 100, 0, 0, 55337, 99167, 0, 'Overseer Brutarg to Player'),

(96402, 0, 0, 'Pitiful.', 12, 0, 100, 0, 0, 55324, 97904, 0, 'Hulking Forgefiend to Player'),
(96402, 0, 1, 'Die in glorious battle!', 12, 0, 100, 0, 0, 55330, 97905, 0, 'Hulking Forgefiend to Player'),
(96402, 0, 2, 'Taste my blade.', 12, 0, 100, 0, 0, 55327, 97902, 0, 'Hulking Forgefiend to Player'),
(96402, 0, 3, 'Death comes soon.', 12, 0, 100, 0, 0, 55332, 97901, 0, 'Hulking Forgefiend to Player'),
(96402, 0, 4, 'Hunt this.', 12, 0, 100, 0, 0, 55328, 97903, 0, 'Hulking Forgefiend to Player'),
(96402, 0, 5, 'For Tyranna!', 12, 0, 100, 0, 0, 55329, 97906, 0, 'Hulking Forgefiend to Player'),
(96402, 0, 6, 'I''m going to destroy you, little demon hunter.', 12, 0, 100, 0, 0, 55325, 97907, 0, 'Hulking Forgefiend to Player'),

(97059, 0, 0, 'Want your little, broken draenei back?', 12, 0, 100, 0, 0, 55281, 99173, 0, 'King Voras to Player'),
(97059, 1, 0, 'My queen''s brood will hatch soon.', 14, 0, 100, 0, 0, 55283, 103500, 0, 'King Voras to Player'),
(97059, 2, 0, '|TInterface\Icons\inv_misc_monsterspidercarapace_01:20|tNearby |cFFFF0000|Hspell:198235|h[Spider Eggs]|h|r will hatch soon if not destroyed!.', 41, 0, 100, 0, 0, 0, 103110, 0, 'King Voras to Player'),
(97059, 3, 0, 'They''ve slain me, my queen...', 14, 0, 100, 0, 0, 55282, 99206, 0, 'King Voras to Player'),

(97706, 0, 0, 'Warn King Voras!', 12, 0, 100, 0, 0, 55175, 103526, 0, 'Fel Weaver to Player'),
(97706, 0, 1, 'Quickly, kill the demon hunter!', 12, 0, 100, 0, 0, 55185, 103528, 0, 'Fel Weaver to Player'),
(97706, 0, 2, 'Come closer, my little friend.', 12, 0, 100, 0, 0, 55178, 103519, 0, 'Fel Weaver to Player'),
(97706, 0, 3, 'Embrace the inevitable.', 12, 0, 100, 0, 0, 55179, 103520, 0, 'Fel Weaver to Player'),
(97706, 0, 4, 'All worlds fall to the Legion.', 12, 0, 100, 0, 0, 55180, 103521, 0, 'Fel Weaver to Player'),

(102724, 0, 0, 'Kill the Illidari', 12, 0, 100, 0, 0, 56992, 96720, 0, 'Vile Soulmaster to Player'),
(102724, 0, 1, 'Your soul will be ours.', 12, 0, 100, 0, 0, 57001, 99614, 0, 'Vile Soulmaster to Player'),
(102724, 0, 2, 'Kill them before they can get up to the Fel Hammer.', 12, 0, 100, 0, 0, 57002, 99615, 0, 'Vile Soulmaster to Player'),
(102724, 0, 3, 'Defend the Soul Engine.', 12, 0, 100, 0, 0, 57003, 99616, 0, 'Vile Soulmaster to Player'),
(102724, 0, 4, 'Your death will be swift and unmerciful.', 12, 0, 100, 0, 0, 57004, 102121, 0, 'Vile Soulmaster to Player'),
(102724, 0, 5, 'Your world will be purged!', 12, 0, 100, 0, 0, 56994, 96722, 0, 'Vile Soulmaster to Player'),
(102724, 1, 0, 'In Sargeras''s name.', 12, 0, 100, 0, 0, 56997, 96725, 0, 'Vile Soulmaster to Player'),

(96499, 0, 0, 'The fel lord is just ahead.', 12, 0, 100, 0, 0, 55237, 98272, 0, 'Jace Darkweaver to Player'),

(102726, 0, 0, 'They have the spectral sight!', 12, 0, 100, 0, 0, 56999, 98223, 0, 'Eredar Sorcerer to Jace Darkweaver'),

(93127, 2, 0, '$n, you made it through!', 14, 0, 100, 0, 0, 55054, 99836, 0, 'Kayn Sunfury to Player'),
(93127, 3, 0, 'Teach us what you have learned, $n.', 12, 0, 100, 0, 0, 55265, 100722, 0, 'Kayn Sunfury to Player'),
(93127, 4, 0, 'Come on, let''s get up there!', 12, 0, 100, 0, 0, 55257, 98957, 0, 'Kayn Sunfury to Player'),

(93716, 0, 0, 'The Legion conquers all.', 12, 0, 100, 0, 0, 55147, 96648, 0, 'Doom Slayer to Player'),
(93716, 0, 1, 'Succulent marrow. Crunchy bones.', 12, 0, 100, 0, 0, 55150, 96651, 0, 'Doom Slayer to Player'),

(95048, 0, 0, 'Deal with these insects, Beliash.', 12, 0, 100, 0, 0, 55071, 96146, 0, 'Brood Queen Tyranna to Player'),

(93221, 0, 0, 'They will die.', 14, 0, 100, 0, 0, 55133, 94990, 0, 'Doom Commander Beliash to Player'),
(93221, 1, 0, 'You won''t survive Inferno Peak...', 12, 0, 100, 0, 0, 55134, 94991, 0, 'Doom Commander Beliash to Player'),
(93221, 2, 0, 'Get away from that spire!', 14, 0, 100, 0, 0, 55140, 103466, 0, 'Doom Commander Beliash to Player'), -- not used yet in scripts

(94654, 0, 0, 'A fatal mistake, mortal.', 12, 0, 100, 0, 0, 55149, 96650, 0, 'Doomguard Eradicator to Player'),
(94654, 0, 1, 'The Legion conquers all.', 12, 0, 100, 0, 0, 55147, 96648, 0, 'Doomguard Eradicator to Player'),
(94654, 0, 2, 'Intruder, your life ends now.', 12, 0, 100, 0, 0, 55146, 96647, 0, 'Doomguard Eradicator to Player'),
(94654, 0, 3, 'Doom!', 12, 0, 100, 0, 0, 55142, 96645, 0, 'Doomguard Eradicator to Player'),
(94654, 0, 4, 'Succulent marrow. Crunchy bones.', 12, 0, 100, 0, 0, 55150, 96651, 0, 'Doomguard Eradicator to Player'),
(94654, 0, 5, 'You do not belong here.', 12, 0, 100, 0, 0, 55148, 96649, 0, 'Doomguard Eradicator to Player'),

(93759, 0, 0, 'I sense greater power within you, $n. Have you stolen a demon''s essence?', 12, 0, 100, 0, 0, 55229, 96428, 0, 'Jace Darkweaver to Player'),
(93759, 1, 0, 'Use the crucible to complete the ritual.', 12, 0, 100, 0, 0, 55242, 96680, 0, 'Jace Darkweaver to Player'),
(93759, 2, 0, 'Beliash is protected by those Spires of Woe. You''ll want to deactivate them.', 12, 0, 100, 0, 0, 55230, 96689, 0, 'Jace Darkweaver to Player'),
(93759, 3, 0, 'Good luck, $n. I''ll see you up in the volcano.', 12, 0, 100, 0, 0, 55232, 101307, 0, 'Jace Darkweaver to Player'),

(96884, 0, 0, 'This demon will die.', 12, 0, 100, 0, 0, 55082, 99743, 0, 'Coilskar Sea-Caller to Player'),
(96884, 0, 1, 'Lady S''theno requested I join you.', 12, 0, 100, 0, 0, 55077, 99738, 0, 'Coilskar Sea-Caller to Player'),
(96884, 0, 2, 'The Coilskar honor their allegiance.', 12, 0, 100, 0, 0, 55084, 99745, 0, 'Coilskar Sea-Caller to Player'),
(96884, 0, 3, 'Lord Illidan leads and the Coilskar follow.', 12, 0, 100, 0, 0, 55081, 99742, 0, 'Coilskar Sea-Caller to Player'),
(96884, 0, 4, 'The Burning Legion will be destroyed.', 12, 0, 100, 0, 0, 55079, 99740, 0, 'Coilskar Sea-Caller to Player'),
(96884, 0, 5, 'Legion magic is nothing compared to that of the naga.', 12, 0, 100, 0, 0, 55080, 99741, 0, 'Coilskar Sea-Caller to Player'),
(96884, 0, 6, 'I have come to your aid.', 12, 0, 100, 0, 0, 55083, 99744, 0, 'Coilskar Sea-Caller to Player'),
(96884, 0, 7, 'The Legion must be stopped before they burn our world.', 12, 0, 100, 0, 0, 55085, 99746, 0, 'Coilskar Sea-Caller to Player'),

(93112, 0, 0, 'For the Legion!', 12, 0, 100, 0, 0, 55192, 96663, 0, 'Felguard Sentry to Player'),
(93112, 0, 1, 'Demon hunters? How did you get here?', 12, 0, 100, 0, 0, 55187, 94934, 0, 'Felguard Sentry to Player'),
(93112, 0, 2, 'Die, Illidari fool.', 12, 0, 100, 0, 0, 55189, 94936, 0, 'Felguard Sentry to Player'),
(93112, 0, 3, 'I''ll rend you limb from limb.', 12, 0, 100, 0, 0, 55188, 94935, 0, 'Felguard Sentry to Demon Hunter'),
(93112, 0, 4, 'Invaders. Warn the Brood Queen!', 12, 0, 100, 0, 0, 55186, 94932, 0, 'Felguard Sentry to Demon Hunter'),
(93112, 0, 5, 'The fel you wield will not be enough.', 12, 0, 100, 0, 0, 55190, 96661, 0, 'Felguard Sentry to Demon Hunter'),
(93112, 0, 6, 'For Brood Queen Tyranna. For the Legion!', 12, 0, 100, 0, 0, 55193, 96664, 0, 'Felguard Sentry to Demon Hunter'),
(93112, 0, 7, 'You dare attack us here?!', 12, 0, 100, 0, 0, 55191, 96662, 0, 'Felguard Sentry to Demon Hunter'),

(96277, 0, 0, 'For the Legion!', 12, 0, 100, 0, 0, 55192, 96663, 0, 'Queen''s Centurion to Player'),
(96277, 0, 1, 'Demon hunters? How did you get here?', 12, 0, 100, 0, 0, 55187, 94934, 0, 'Queen''s Centurion to Player'),
(96277, 0, 2, 'Die, Illidari fool.', 12, 0, 100, 0, 0, 55189, 94936, 0, 'Queen''s Centurion to Player'),
(96277, 0, 3, 'I''ll rend you limb from limb.', 12, 0, 100, 0, 0, 55188, 94935, 0, 'Queen''s Centurion to Demon Hunter'),
(96277, 0, 4, 'Invaders. Warn the Brood Queen!', 12, 0, 100, 0, 0, 55186, 94932, 0, 'Queen''s Centurion to Demon Hunter'),
(96277, 0, 5, 'The fel you wield will not be enough.', 12, 0, 100, 0, 0, 55190, 96661, 0, 'Queen''s Centurion to Demon Hunter'),
(96277, 0, 6, 'For Brood Queen Tyranna. For the Legion!', 12, 0, 100, 0, 0, 55193, 96664, 0, 'Queen''s Centurion to Demon Hunter'),
(96277, 0, 7, 'You dare attack us here?!', 12, 0, 100, 0, 0, 55191, 96662, 0, 'Queen''s Centurion to Demon Hunter'),

(96494, 0, 0, 'For the Legion!', 12, 0, 100, 0, 0, 55192, 96663, 0, 'Felguard Butcher to Player'),
(96494, 0, 1, 'Demon hunters? How did you get here?', 12, 0, 100, 0, 0, 55187, 94934, 0, 'Felguard Butcher to Player'),
(96494, 0, 2, 'Die, Illidari fool.', 12, 0, 100, 0, 0, 55189, 94936, 0, 'Felguard Butcher to Player'),
(96494, 0, 3, 'I''ll rend you limb from limb.', 12, 0, 100, 0, 0, 55188, 94935, 0, 'Felguard Butcher to Demon Hunter'),
(96494, 0, 4, 'Invaders. Warn the Brood Queen!', 12, 0, 100, 0, 0, 55186, 94932, 0, 'Felguard Butcher to Demon Hunter'),
(96494, 0, 5, 'The fel you wield will not be enough.', 12, 0, 100, 0, 0, 55190, 96661, 0, 'Felguard Butcher to Demon Hunter'),
(96494, 0, 6, 'For Brood Queen Tyranna. For the Legion!', 12, 0, 100, 0, 0, 55193, 96664, 0, 'Felguard Butcher to Demon Hunter'),
(96494, 0, 7, 'You dare attack us here?!', 12, 0, 100, 0, 0, 55191, 96662, 0, 'Felguard Butcher to Demon Hunter'),

(95226, 0, 0, 'So eager to be enslaved.', 12, 0, 100, 0, 0, 55018, 97913, 0, 'Anguish Jailer to Player'),
(95226, 0, 1, 'In this place, you are the hunted.', 12, 0, 100, 0, 0, 55019, 97914, 0, 'Anguish Jailer to Player'),
(95226, 0, 2, 'I am your judge, jury, and executioner.', 12, 0, 100, 0, 0, 55020, 97915, 0, 'Anguish Jailer to Player'),
(95226, 0, 3, 'Into my cage you go.', 12, 0, 100, 0, 0, 55017, 97912, 0, 'Anguish Jailer to Player'),
(95226, 0, 4, 'I''ll crack open your flesh and feed upon your soul.', 12, 0, 100, 0, 0, 55016, 97911, 0, 'Anguish Jailer to Player'),
(95226, 0, 5, 'A new prisoner for the taking.', 12, 0, 100, 0, 0, 55014, 97909, 0, 'Anguish Jailer to Player'),
(95226, 0, 6, 'Your soul will be mine.', 12, 0, 100, 0, 0, 55013, 97908, 0, 'Anguish Jailer to Player'),
(95226, 0, 7, 'Your armies are nothing, demon hunter.', 12, 0, 100, 0, 0, 55015, 97910, 0, 'Anguish Jailer to Player'),

(96279, 0, 0, 'So eager to be enslaved.', 12, 0, 100, 0, 0, 55018, 97913, 0, 'Mardum Executioner to Player'),
(96279, 0, 1, 'In this place, you are the hunted.', 12, 0, 100, 0, 0, 55019, 97914, 0, 'Mardum Executioner to Player'),
(96279, 0, 2, 'I am your judge, jury, and executioner.', 12, 0, 100, 0, 0, 55020, 97915, 0, 'Mardum Executioner to Player'),
(96279, 0, 3, 'Into my cage you go.', 12, 0, 100, 0, 0, 55017, 97912, 0, 'Mardum Executioner to Player'),
(96279, 0, 4, 'I''ll crack open your flesh and feed upon your soul.', 12, 0, 100, 0, 0, 55016, 97911, 0, 'Mardum Executioner to Player'),
(96279, 0, 5, 'A new prisoner for the taking.', 12, 0, 100, 0, 0, 55014, 97909, 0, 'Mardum Executioner to Player'),
(96279, 0, 6, 'Your soul will be mine.', 12, 0, 100, 0, 0, 55013, 97908, 0, 'Mardum Executioner to Player'),
(96279, 0, 7, 'Your armies are nothing, demon hunter.', 12, 0, 100, 0, 0, 55015, 97910, 0, 'Mardum Executioner to Player'),

(98229, 2, 0, 'Cyana, Jace, Allari... find the keystone.', 12, 0, 100, 0, 0, 55144, 100341, 0, 'Kayn Sunfury <Illidari> to Player'),
(98229, 3, 0, 'Now, let''s see about activating that gateway.', 12, 0, 100, 0, 0, 55143, 100136, 0, 'Kayn Sunfury <Illidari> to Player'),

(98484, 0, 0, 'Taste my blade.', 12, 0, 100, 0, 0, 55327, 97902, 0, 'Mo''arg Brute to Player'),
(98484, 0, 1, 'Ahahahahaha! I will cut you down.', 12, 0, 100, 0, 0, 55326, 94883, 0, 'Mo''arg Brute to Player'),
(98484, 0, 2, 'Hunt this.', 12, 0, 100, 0, 0, 55328, 97903, 0, 'Mo''arg Brute to Player'),
(98484, 0, 3, 'Death comes soon.', 12, 0, 100, 0, 0, 55332, 97901, 0, 'Mo\'arg Brute to Player'), -- BroadcastTextID: 97901 - 127315
(98484, 0, 4, 'For Tyranna!', 12, 0, 100, 0, 0, 55329, 97906, 0, 'Mo\'arg Brute to Player'),
(98484, 0, 5, 'Pitiful.', 12, 0, 100, 0, 0, 55324, 97904, 0, 'Mo\'arg Brute to Player'),
(98484, 0, 6, 'Die in glorious battle!', 12, 0, 100, 0, 0, 55330, 97905, 0, 'Mo\'arg Brute to Player'),
(98484, 0, 7, 'I''m going to destroy you, little demon hunter.', 12, 0, 100, 0, 0, 55325, 97907, 0, 'Mo\'arg Brute to Player'),
(98484, 0, 8, 'I will crush you.', 12, 0, 100, 0, 0, 55331, 102134, 0, 'Mo\'arg Brute to Player'),

(96400, 0, 0, 'Taste my blade.', 12, 0, 100, 0, 0, 55327, 97902, 0, 'Mo''arg Brute to Player'),
(96400, 0, 1, 'Ahahahahaha! I will cut you down.', 12, 0, 100, 0, 0, 55326, 94883, 0, 'Mo''arg Brute to Player'),
(96400, 0, 2, 'Hunt this.', 12, 0, 100, 0, 0, 55328, 97903, 0, 'Mo''arg Brute to Player'),
(96400, 0, 3, 'Death comes soon.', 12, 0, 100, 0, 0, 55332, 97901, 0, 'Mo\'arg Brute to Player'), -- BroadcastTextID: 97901 - 127315
(96400, 0, 4, 'For Tyranna!', 12, 0, 100, 0, 0, 55329, 97906, 0, 'Mo\'arg Brute to Player'),
(96400, 0, 5, 'Pitiful.', 12, 0, 100, 0, 0, 55324, 97904, 0, 'Mo\'arg Brute to Player'),
(96400, 0, 6, 'Die in glorious battle!', 12, 0, 100, 0, 0, 55330, 97905, 0, 'Mo\'arg Brute to Player'),
(96400, 0, 7, 'I''m going to destroy you, little demon hunter.', 12, 0, 100, 0, 0, 55325, 97907, 0, 'Mo\'arg Brute to Player'),
(96400, 0, 8, 'I will crush you.', 12, 0, 100, 0, 0, 55331, 102134, 0, 'Mo\'arg Brute to Player'),

(98486, 0, 0, 'Brood Queen Tyranna orders your death.', 12, 0, 100, 0, 0, 55366, 98762, 0, 'Wrath Warrior to Player'),
(98486, 0, 1, 'This is where you die.', 12, 0, 100, 0, 0, 55362, 98765, 0, 'Wrath Warrior to Player'),
(98486, 0, 2, 'I live to serve.', 12, 0, 100, 0, 0, 55363, 98759, 0, 'Wrath Warrior to Player'),
(98486, 0, 3, 'My life for the Legion', 12, 0, 100, 0, 0, 55364, 98760, 0, 'Wrath Warrior to Player'),
(98486, 0, 4, 'You will not gain the keystone.', 12, 0, 100, 0, 0, 55365, 98761, 0, 'Wrath Warrior to Player'),
(98486, 0, 5, 'You are outmatched and outnumbered.', 12, 0, 100, 0, 0, 55367, 98764, 0, 'Wrath Warrior to Player'),
(98486, 0, 6, 'We will cleanse the universe in fire.', 12, 0, 100, 0, 0, 55370, 98766, 0, 'Wrath Warrior to Player'),
(98486, 0, 7, 'My blade will cut through you.', 12, 0, 100, 0, 0, 55371, 98763, 0, 'Wrath Warrior to Player'),

(97034, 0, 0, 'Brood Queen Tyranna orders your death.', 12, 0, 100, 0, 0, 55366, 98762, 0, 'Fury Champion to Player'),
(97034, 0, 1, 'This is where you die.', 12, 0, 100, 0, 0, 55362, 98765, 0, 'Fury Champion to Player'),
(97034, 0, 2, 'I live to serve.', 12, 0, 100, 0, 0, 55363, 98759, 0, 'Fury Champion to Player'),
(97034, 0, 3, 'My life for the Legion', 12, 0, 100, 0, 0, 55364, 98760, 0, 'Fury Champion to Player'),
(97034, 0, 4, 'You will not gain the keystone.', 12, 0, 100, 0, 0, 55365, 98761, 0, 'Fury Champion to Player'),
(97034, 0, 5, 'You are outmatched and outnumbered.', 12, 0, 100, 0, 0, 55367, 98764, 0, 'Fury Champion to Player'),
(97034, 0, 6, 'We will cleanse the universe in fire.', 12, 0, 100, 0, 0, 55370, 98766, 0, 'Fury Champion to Player'),
(97034, 0, 7, 'My blade will cut through you.', 12, 0, 100, 0, 0, 55371, 98763, 0, 'Fury Champion to Player'),

(98497, 0, 0, 'I''m so hungry.', 12, 0, 100, 0, 0, 55211, 102142, 0, 'Imp Mother to Player'),
(98497, 0, 1, 'My meal comes to me.', 12, 0, 100, 0, 0, 55212, 102143, 0, 'Imp Mother to Player'),
(98497, 0, 2, 'Climb inside my mouth, tiny thing.', 12, 0, 100, 0, 0, 55213, 102144, 0, 'Imp Mother to Player'),
(98497, 0, 3, 'Come, my little imps, dance for mother.', 12, 0, 100, 0, 0, 55214, 102145, 0, 'Imp Mother Player'),
(98497, 0, 4, 'My children will cook you up nicely.', 12, 0, 100, 0, 0, 55215, 102146, 0, 'Imp Mother to Player'),
(98497, 0, 5, 'You''ll die for this!', 12, 0, 100, 0, 0, 55216, 102147, 0, 'Imp Mother to Player'),
(98497, 0, 6, 'Have you come to play with my little imps?', 12, 0, 100, 0, 0, 55217, 102149, 0, 'Imp Mother to Player'),
(98497, 0, 7, 'The Legion''s victory is inevitable, child.', 12, 0, 100, 0, 0, 55218, 102149, 0, 'Imp Mother to Player'),
(98497, 0, 8, 'I''ll deliver you to Tyranna myself.', 12, 0, 100, 0, 0, 55219, 102150, 0, 'Imp Mother to Player'),
(98497, 0, 9, 'Filthy, little elf. I can taste the fel energy on you.', 12, 0, 100, 0, 0, 55220, 102151, 0, 'Imp Mother Player'),
(98497, 0, 10, 'Intruders! Someone warn the Doom Commander!', 12, 0, 100, 0, 0, 55221, 102152, 0, 'Imp Mother to Player');

