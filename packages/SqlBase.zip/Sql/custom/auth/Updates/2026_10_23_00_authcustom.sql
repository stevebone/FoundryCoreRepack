DELETE FROM `build_info` WHERE `build` IN (70529);
INSERT INTO `build_info` (`build`,`majorVersion`,`minorVersion`,`bugfixVersion`,`hotfixVersion`) VALUES
(70529,12,1,5,NULL);

DELETE FROM `build_auth_key` WHERE `build`=70529;
INSERT INTO `build_auth_key` (`build`,`platform`,`arch`,`type`,`key`) VALUES
(70529,'Win','x64','WoW',0x179D3DC3235629D07113A9B3867F97A7);

UPDATE `realmlist` SET `gamebuild`=70529 WHERE `gamebuild`=70448;

ALTER TABLE `realmlist` CHANGE `gamebuild` `gamebuild` int unsigned NOT NULL DEFAULT '70529';